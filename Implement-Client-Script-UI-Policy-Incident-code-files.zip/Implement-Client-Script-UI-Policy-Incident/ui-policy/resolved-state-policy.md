# UI Policy setup — Resolution fields

## Recommended configuration (no script required)

Create a UI Policy for the **Incident [incident]** table.

- **Short description:** Require resolution details when resolved
- **Condition:** State is Resolved
- **On load:** true
- **Reverse if false:** true

Create these UI Policy Actions (field labels may vary by instance):

| Field | Visible | Mandatory |
|---|---|---|
| `close_code` (Resolution code) | True | True |
| `close_notes` (Resolution notes / Close notes) | True | True |

If your instance uses different field names or state choice values, select the matching fields/choice from the form. Test by changing State to Resolved and then changing it back.

## Optional script-based policy

If your lab requires **Run scripts**, use the scripts in this folder. Set the same condition (State is Resolved), and enable **Run scripts**. Do not rely on the script alone if the project rubric expects UI Policy Actions.
