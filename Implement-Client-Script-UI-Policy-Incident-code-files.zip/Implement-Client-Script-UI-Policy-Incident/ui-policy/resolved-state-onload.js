function onCondition() {
    // This function runs when the UI Policy condition is evaluated.
    // The UI Policy Actions should also be configured as described in
    // resolved-state-policy.md.
    var isResolved = (g_form.getValue('state') === '6');

    if (isResolved) {
        g_form.setMandatory('close_code', true);
        g_form.setMandatory('close_notes', true);
        g_form.setDisplay('close_code', true);
        g_form.setDisplay('close_notes', true);
    } else {
        g_form.setMandatory('close_code', false);
        g_form.setMandatory('close_notes', false);
    }
}
