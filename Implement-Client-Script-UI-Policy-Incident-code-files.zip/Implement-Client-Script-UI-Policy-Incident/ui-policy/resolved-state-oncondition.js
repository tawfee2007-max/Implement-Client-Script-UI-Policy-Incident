function onCondition() {
    // Use this as the UI Policy's Execute if false script, if scripts are enabled.
    // Change '6' if the Resolved choice value differs in your instance.
    g_form.setMandatory('close_code', false);
    g_form.setMandatory('close_notes', false);
}
