# Implement Client Script & UI Policy (Incident) — ServiceNow Project

This repository contains example client-side scripts and a UI Policy setup for the **Incident** form in ServiceNow.

## Project goal
Improve the Incident form by:
- validating required information before submission;
- guiding users when they create or update an incident;
- displaying and requiring resolution details when an incident is resolved.

> **Important:** These are starter examples. ServiceNow field names and choice values can vary by instance. Test in a Personal Developer Instance (PDI) or a permitted lab instance before using them. These files do not automatically install the configuration into ServiceNow.

## Folder structure

```text
Implement-Client-Script-UI-Policy-Incident/
├── README.md
├── client-scripts/
│   ├── incident-onload.js
│   ├── incident-short-description-onchange.js
│   └── incident-onsubmit-validation.js
└── ui-policy/
    ├── resolved-state-policy.md
    ├── resolved-state-onload.js
    └── resolved-state-oncondition.js
```

## 1. Create the Client Scripts in ServiceNow

Navigate to **System Definition → Client Scripts → New** (menu labels can vary).

For each script, select:
- **Table:** Incident `[incident]`
- **UI Type:** All (or the UI type required by your lab)
- **Type:** Use the type listed in each filename section below
- **Active:** checked

Copy the corresponding JavaScript into the **Script** field.

### Script list

| File | Client Script type | Field name |
|---|---|---|
| `incident-onload.js` | onLoad | — |
| `incident-short-description-onchange.js` | onChange | `short_description` |
| `incident-onsubmit-validation.js` | onSubmit | — |

## 2. Configure the UI Policy

Open **System UI → UI Policies** (or search for *UI Policies*) and create a policy:
- **Table:** Incident `[incident]`
- **Short description:** Require resolution details when resolved
- **Conditions:** State **is** Resolved
- **On load:** checked
- **Reverse if false:** checked
- **Global:** leave according to your lab requirements

Add UI Policy Actions for:
- `close_code` (sometimes labelled Resolution code): **Mandatory = true**, **Visible = true**
- `close_notes` (sometimes labelled Resolution notes/Close notes): **Mandatory = true**, **Visible = true**

When the condition is false, Reverse if false should return these fields to their normal state. Check your instance's field names and choice values.

If your lab specifically requires scripts, enable **Run scripts** and use the optional scripts in `ui-policy/`. The UI Policy Actions are usually the simpler approach.

## 3. Test checklist

1. Open a new Incident.
2. Confirm the onLoad message appears.
3. Enter a short description and confirm the onChange message appears.
4. Try submitting without a short description; submission should be blocked.
5. Set State to Resolved and confirm resolution fields are visible and mandatory.
6. Change State away from Resolved and confirm the UI Policy reverses the mandatory state.
7. Test both a new and an existing incident.

## 4. Notes for GitHub

Suggested repository description:

> ServiceNow project demonstrating Client Scripts and UI Policies on the Incident form, including form guidance, client-side validation, and resolution-field rules.

Do not commit passwords, tokens, instance credentials, personal data, or screenshots containing private information.
