function onSubmit() {
    var shortDescription = (g_form.getValue('short_description') || '').trim();

    if (!shortDescription) {
        g_form.showFieldMsg(
            'short_description',
            'Short description is required before submitting this incident.',
            'error'
        );
        g_form.setFocus('short_description');
        return false;
    }

    // Client-side check: keep the description meaningful.
    var description = (g_form.getValue('description') || '').trim();

    if (description.length > 0 && description.length < 10) {
        g_form.addErrorMessage(
            'Please provide at least 10 characters in Description, or leave it blank if it is optional.'
        );
        g_form.setFocus('description');
        return false;
    }

    return true;
}
