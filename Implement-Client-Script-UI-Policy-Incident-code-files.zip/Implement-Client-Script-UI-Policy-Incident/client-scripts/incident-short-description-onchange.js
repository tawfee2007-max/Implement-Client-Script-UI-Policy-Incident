function onChange(control, oldValue, newValue, isLoading, isTemplate) {
    if (isLoading || isTemplate) {
        return;
    }

    // Remove leading/trailing spaces before validating the field.
    var shortDescription = (newValue || '').trim();

    if (shortDescription.length === 0) {
        g_form.showFieldMsg(
            'short_description',
            'Enter a short description so the incident can be identified easily.',
            'error'
        );
        return;
    }

    if (shortDescription.length < 10) {
        g_form.showFieldMsg(
            'short_description',
            'Add a little more detail (at least 10 characters is recommended).',
            'info'
        );
    }
}
