function onLoad() {
    // Show a brief guide when the Incident form loads.
    g_form.addInfoMessage(
        'Incident form ready. Complete the short description and required details before submitting.'
    );
}
